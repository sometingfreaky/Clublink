<?php
/**
 * Shared helper functions: sessions, escaping, CSRF, flash messages,
 * authentication guards, prepared-statement helpers and image upload.
 */

// ---------- Session (hardened cookie settings) ----------
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,        // JavaScript cannot read the session cookie
        'samesite' => 'Lax',       // basic cross-site request protection
    ]);
    session_start();
}

const CATEGORIES = ['Social', 'Sports', 'Academic', 'Culture'];

// ---------- Output escaping (prevents XSS) ----------
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

// ---------- Redirect ----------
function redirect(string $url): void
{
    header("Location: $url");
    exit();
}

// ---------- CSRF protection ----------
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    $sent = $_POST['csrf'] ?? '';
    if (!is_string($sent) || !hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        http_response_code(403);
        die("Security check failed (invalid or expired form). Go back, refresh the page and try again.");
    }
}

// ---------- Flash messages (shown once after a redirect) ----------
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function render_flash(): string
{
    $out = '';
    foreach ($_SESSION['flash'] ?? [] as $f) {
        $icon = $f['type'] === 'success' ? 'fa-circle-check' : ($f['type'] === 'danger' ? 'fa-circle-exclamation' : 'fa-circle-info');
        $out .= '<div class="alert alert-' . e($f['type']) . '" role="alert"><i class="fa-solid ' . $icon . '"></i> '
              . '<span>' . e($f['message']) . '</span>'
              . '<button type="button" class="alert-close" aria-label="Dismiss">&times;</button></div>';
    }
    unset($_SESSION['flash']);
    return $out;
}

// ---------- Authentication guards ----------
function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function is_admin(): bool
{
    return is_logged_in() && ($_SESSION['role'] ?? '') === 'admin';
}

function require_login(string $base = ''): void
{
    if (!is_logged_in()) {
        flash('info', 'Please log in to continue.');
        redirect($base . 'login.php');
    }
}

function require_admin(string $base = '../'): void
{
    if (!is_logged_in()) {
        flash('info', 'Please log in as an administrator.');
        redirect($base . 'login.php');
    }
    if (!is_admin()) {
        http_response_code(403);
        die("<h2 style='font-family:sans-serif;text-align:center;margin-top:3rem'>Access denied. Administrators only.</h2>"
          . "<p style='font-family:sans-serif;text-align:center'><a href='{$base}index.php'>Back to site</a></p>");
    }
}

// ---------- Prepared-statement helpers (prevent SQL injection) ----------
function q(mysqli $c, string $sql, string $types = '', array $params = []): mysqli_stmt
{
    $stmt = $c->prepare($sql);
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt;
}

function rows(mysqli $c, string $sql, string $types = '', array $params = []): array
{
    return q($c, $sql, $types, $params)->get_result()->fetch_all(MYSQLI_ASSOC);
}

function row(mysqli $c, string $sql, string $types = '', array $params = []): ?array
{
    $r = rows($c, $sql, $types, $params);
    return $r[0] ?? null;
}

function val(mysqli $c, string $sql, string $types = '', array $params = [])
{
    $r = row($c, $sql, $types, $params);
    return $r ? array_values($r)[0] : null;
}

// ---------- Formatting ----------
function fmt_date(?string $d, string $format = 'D, j M Y \a\t H:i'): string
{
    return $d ? date($format, strtotime($d)) : '';
}

function excerpt(string $text, int $len = 100): string
{
    return mb_strlen($text) > $len ? mb_substr($text, 0, $len) . '…' : $text;
}

function club_image(?string $name, string $base = ''): string
{
    $file = $name ?: 'default.jpg';
    return $base . 'assets/images/' . rawurlencode($file);
}

// ---------- Safe image upload ----------
/**
 * Validates and stores an uploaded image. Returns the new file name, or null
 * (and fills $error) on failure. Checks: upload error, size (2 MB), real MIME
 * type via finfo, real image via getimagesize, and generates a random name so
 * a user-supplied name can never overwrite files or run as PHP.
 */
function upload_image(array $file, ?string &$error, string $dir): ?string
{
    $error = null;
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null; // nothing uploaded - not an error
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Image upload failed. Try a smaller file.';
        return null;
    }
    if ($file['size'] > 2 * 1024 * 1024) {
        $error = 'Image must be 2 MB or smaller.';
        return null;
    }
    $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($allowed[$mime]) || @getimagesize($file['tmp_name']) === false) {
        $error = 'Only JPG, PNG, WEBP or GIF images are allowed.';
        return null;
    }
    $name = 'club_' . bin2hex(random_bytes(8)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], rtrim($dir, '/') . '/' . $name)) {
        $error = 'Could not save the image on the server.';
        return null;
    }
    return $name;
}

function delete_uploaded_image(?string $name, string $dir): void
{
    // Only remove files this app created (club_*), never the bundled sample images
    if ($name && strpos($name, 'club_') === 0 && preg_match('/^club_[a-f0-9]{16}\.(jpg|png|webp|gif)$/', $name)) {
        $path = rtrim($dir, '/') . '/' . $name;
        if (is_file($path)) {
            @unlink($path);
        }
    }
}
