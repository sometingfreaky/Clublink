<?php
/**
 * Bootstrap file: every page starts with
 *     $base = '';            // or '../' for pages inside /admin
 *     require __DIR__ . '/includes/init.php';
 */
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/db.php';

// Security headers (cheap, effective hardening)
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');

$base = $base ?? '';
