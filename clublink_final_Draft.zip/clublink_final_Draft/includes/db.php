<?php
/**
 * Database connection (MySQL / MariaDB via mysqli).
 * XAMPP defaults: user "root", empty password.
 * Change the values below if your setup uses a different password or port.
 */
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "clublink_db";
$db_port = 3306;

// Throw exceptions instead of printing raw errors (details stay out of the browser)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name, $db_port);
    $conn->set_charset("utf8mb4");
} catch (mysqli_sql_exception $ex) {
    error_log("DB connection failed: " . $ex->getMessage());
    http_response_code(500);
    die("<h2 style='font-family:sans-serif;text-align:center;margin-top:3rem'>Database connection failed.</h2>"
      . "<p style='font-family:sans-serif;text-align:center'>Start MySQL and make sure the <code>clublink_db</code> database is imported (see README.md).</p>");
}
