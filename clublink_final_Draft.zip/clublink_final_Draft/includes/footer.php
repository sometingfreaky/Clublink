    </main>
    <footer class="site-footer">
        <div class="footer-grid">
            <section>
                <img src="<?= $base ?>assets/images/logo-light.png" alt="Club Link" width="130" height="82">
                <p>The one place for NUST students to discover clubs, join communities and never miss a campus event.</p>
            </section>
            <section>
                <h2>Explore</h2>
                <ul>
                    <li><a href="<?= $base ?>clubs.php">Find a club</a></li>
                    <li><a href="<?= $base ?>events.php">Upcoming events</a></li>
                    <li><a href="<?= $base ?>about.php">About us</a></li>
                    <li><a href="<?= $base ?>contact.php">Contact</a></li>
                </ul>
            </section>
            <section>
                <h2>Categories</h2>
                <ul>
                    <?php foreach (CATEGORIES as $c): ?>
                        <li><a href="<?= $base ?>clubs.php?category=<?= urlencode($c) ?>"><?= e($c) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </section>
            <section>
                <h2>Contact</h2>
                <address>
                    <p><i class="fa-solid fa-location-dot"></i> NUST, 13 Jackson Kaujeua St, Windhoek</p>
                    <p><i class="fa-solid fa-envelope"></i> clublink@nust.na</p>
                </address>
            </section>
        </div>
        <p class="copyright">&copy; <?= date('Y') ?> Club Link &middot; NUST WAD621S Group Assignment</p>
    </footer>
    <button type="button" id="backToTop" class="back-to-top" aria-label="Back to top"><i class="fa-solid fa-arrow-up"></i></button>
    <script src="<?= $base ?>assets/js/script.js"></script>
</body>
</html>
