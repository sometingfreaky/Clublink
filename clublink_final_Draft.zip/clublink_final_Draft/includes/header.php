<?php
// Expects: $base, optionally $page_title, $page_desc
$current = basename($_SERVER['SCRIPT_NAME']);
$in_admin = ($base === '../');
if ($in_admin) { $current = ''; }   // no public link is "active" inside the admin area
$title = isset($page_title) ? $page_title . ' | Club Link' : 'Club Link | NUST Student Clubs';
$desc = $page_desc ?? 'Discover, join and manage student clubs and events at the Namibia University of Science and Technology.';
function nav_link(string $file, string $label, string $icon, string $current, string $base): string
{
    $active = ($current === $file) ? ' class="active" aria-current="page"' : '';
    return '<li><a href="' . $base . $file . '"' . $active . '><i class="fa-solid ' . $icon . '"></i> ' . $label . '</a></li>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= e($desc) ?>">
    <title><?= e($title) ?></title>
    <link rel="icon" type="image/png" href="<?= $base ?>assets/images/favicon.png">
    <link rel="stylesheet" href="<?= $base ?>assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        // Apply saved theme before first paint to avoid a flash
        try { if (localStorage.getItem('theme') === 'dark') document.documentElement.setAttribute('data-theme', 'dark'); } catch (e) {}
    </script>
</head>
<body class="<?= $in_admin ? 'admin-page' : '' ?>">
    <a class="skip-link" href="#main">Skip to main content</a>
    <header class="site-header">
        <nav class="navbar" aria-label="Main navigation">
            <a class="brand" href="<?= $base ?>index.php" aria-label="Club Link home">
                <img src="<?= $base ?>assets/images/logo.png" alt="Club Link logo" width="120" height="76">
            </a>
            <button class="nav-toggle" id="navToggle" aria-label="Toggle menu" aria-expanded="false" aria-controls="navMenu">
                <i class="fa-solid fa-bars"></i>
            </button>
            <ul class="nav-menu" id="navMenu">
                <?= nav_link('index.php', 'Home', 'fa-house', $current, $base) ?>
                <?= nav_link('clubs.php', 'Clubs', 'fa-magnifying-glass', $current, $base) ?>
                <?= nav_link('events.php', 'Events', 'fa-calendar-days', $current, $base) ?>
                <?= nav_link('about.php', 'About', 'fa-circle-info', $current, $base) ?>
                <?= nav_link('contact.php', 'Contact', 'fa-envelope', $current, $base) ?>
                <?php if (is_logged_in()): ?>
                    <?= nav_link('dashboard.php', 'Dashboard', 'fa-table-columns', $current, $base) ?>
                    <?php if (is_admin()): ?>
                        <li><a href="<?= $base ?><?= $in_admin ? 'index.php' : 'admin/index.php' ?>" class="<?= $in_admin ? 'active' : '' ?> admin-link"><i class="fa-solid fa-shield-halved"></i> Admin</a></li>
                    <?php endif; ?>
                    <li><a href="<?= $base ?>logout.php" class="btn btn-small btn-outline"><i class="fa-solid fa-right-from-bracket"></i> Logout (<?= e(explode(' ', $_SESSION['name'] ?? 'User')[0]) ?>)</a></li>
                <?php else: ?>
                    <?= nav_link('login.php', 'Login', 'fa-right-to-bracket', $current, $base) ?>
                    <li><a href="<?= $base ?>register.php" class="btn btn-small"><i class="fa-solid fa-user-plus"></i> Sign Up</a></li>
                <?php endif; ?>
                <li><button type="button" class="theme-toggle" id="themeToggle" aria-label="Switch between light and dark theme"><i class="fa-solid fa-moon"></i></button></li>
            </ul>
        </nav>
    </header>
    <main id="main" class="container">
        <?= render_flash() ?>
