-- ============================================================
-- Club Link (CampusConnect) - NUST Student Clubs Platform
-- WAD621S Group Assignment 2026
-- Import this file in phpMyAdmin (Import tab) or run:
--   mysql -u root < clublink_db.sql
-- It creates the database, all tables, and sample data.
-- ============================================================

CREATE DATABASE IF NOT EXISTS clublink_db
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE clublink_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS event_rsvps;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS memberships;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS clubs;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- USERS ----------
CREATE TABLE users (
    user_id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name   VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,              -- bcrypt hash from password_hash()
    role        ENUM('student','admin') NOT NULL DEFAULT 'student',
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- CLUBS ----------
CREATE TABLE clubs (
    club_id       INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    club_name     VARCHAR(120) NOT NULL UNIQUE,
    category      ENUM('Social','Sports','Academic','Culture') NOT NULL,
    description   TEXT NOT NULL,
    meeting_time  VARCHAR(100) NOT NULL DEFAULT 'To be announced',
    location      VARCHAR(120) NOT NULL DEFAULT 'NUST Main Campus',
    image         VARCHAR(255) NOT NULL DEFAULT 'default.jpg',
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_clubs_category (category)
) ENGINE=InnoDB;

-- ---------- MEMBERSHIPS (users <-> clubs, many-to-many) ----------
CREATE TABLE memberships (
    membership_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id       INT UNSIGNED NOT NULL,
    club_id       INT UNSIGNED NOT NULL,
    joined_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_member (user_id, club_id),
    CONSTRAINT fk_mem_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_mem_club FOREIGN KEY (club_id) REFERENCES clubs(club_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- EVENTS (one club has many events) ----------
CREATE TABLE events (
    event_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    club_id     INT UNSIGNED NOT NULL,
    title       VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    event_date  DATETIME NOT NULL,
    location    VARCHAR(120) NOT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_events_date (event_date),
    CONSTRAINT fk_event_club FOREIGN KEY (club_id) REFERENCES clubs(club_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- EVENT RSVPS (users <-> events, many-to-many) ----------
CREATE TABLE event_rsvps (
    rsvp_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    event_id   INT UNSIGNED NOT NULL,
    user_id    INT UNSIGNED NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_rsvp (event_id, user_id),
    CONSTRAINT fk_rsvp_event FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE CASCADE,
    CONSTRAINT fk_rsvp_user  FOREIGN KEY (user_id)  REFERENCES users(user_id)  ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- CONTACT MESSAGES ----------
CREATE TABLE messages (
    message_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL,
    subject    VARCHAR(150) NOT NULL,
    message    TEXT NOT NULL,
    is_read    TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- SAMPLE DATA
-- Demo logins:
--   Admin   : admin@nust.na    / Admin@123
--   Student : student@nust.na  / Student@123
-- ============================================================
INSERT INTO users (full_name, email, password, role) VALUES
('System Administrator', 'admin@nust.na',   '$2y$10$dcGlmQEaqpn2VIGzU66yO.CIlrSZcTSayMPEm.IPogAadM1qGwS3G', 'admin'),
('Demo Student',         'student@nust.na', '$2y$10$2Vry9CYwNok5vjmyL.wOIe1xPJB.DDQKF2uNRIF.2Rab2KcG434eG', 'student');

INSERT INTO clubs (club_name, category, description, meeting_time, location, image) VALUES
('NUST Chess Club', 'Academic',
 'Sharpen your strategic thinking at the NUST Chess Club. We welcome complete beginners and seasoned players alike, with weekly casual games, coaching sessions and inter-university tournaments throughout the year.',
 'Wednesdays 16:00', 'Library Seminar Room', 'chess.jpg'),
('NUST Football Club', 'Sports',
 'Train, play and represent NUST on the pitch. The football club runs open training sessions, internal leagues and competes in the Namibian university sports championships.',
 'Tuesdays & Thursdays 17:30', 'NUST Sports Field', 'footbal.jpg'),
('Debate Society', 'Academic',
 'Build confidence, public speaking and critical thinking skills. The Debate Society hosts weekly practice rounds, mock parliaments and national debating competitions.',
 'Mondays 18:00', 'Lecture Hall B2', 'debate.jpg'),
('Culture & Heritage Club', 'Culture',
 'Celebrate Namibia''s rich diversity through music, dance, food and storytelling. The club organises the annual Culture Day and community outreach performances.',
 'Fridays 15:00', 'Student Centre', 'culture.jpg'),
('Coding & Robotics Society', 'Academic',
 'A community for students who love building things. Hackathons, web and mobile development workshops, Arduino projects and peer mentoring for first-year programmers.',
 'Saturdays 10:00', 'ICT Lab 3', 'default.jpg'),
('Photography & Film Club', 'Social',
 'Learn to tell stories with a camera. Photo walks around Windhoek, editing workshops, short-film screenings and an annual campus photo exhibition.',
 'Fridays 16:30', 'Media Studio', 'default.jpg'),
('Hiking & Outdoors Club', 'Sports',
 'Explore Namibia''s landscapes with fellow students. Day hikes around Windhoek, weekend camping trips and basic outdoor-safety training.',
 'Last Sunday of the month 07:00', 'Student Centre Parking', 'default.jpg'),
('Entrepreneurship Society', 'Social',
 'Turn ideas into businesses. Pitch nights, guest speakers from local start-ups, and a mentorship programme for student founders.',
 'Thursdays 18:00', 'Business Incubator', 'default.jpg');

INSERT INTO memberships (user_id, club_id) VALUES (2, 1), (2, 5);

INSERT INTO events (club_id, title, description, event_date, location) VALUES
(1, 'Freshers Chess Tournament', 'A friendly knockout tournament for new players. Boards and clocks are provided.', DATE_ADD(NOW(), INTERVAL 5 DAY), 'Library Seminar Room'),
(2, 'Inter-Faculty Football Cup', 'Faculties compete for the cup. Come and support your team!', DATE_ADD(NOW(), INTERVAL 9 DAY), 'NUST Sports Field'),
(3, 'Open Debate Night: AI in Education', 'Motion: "This house believes AI will improve university learning." Everyone is welcome to speak.', DATE_ADD(NOW(), INTERVAL 12 DAY), 'Lecture Hall B2'),
(4, 'Culture Day Showcase', 'Traditional dance, music, food stalls and fashion from across Namibia.', DATE_ADD(NOW(), INTERVAL 20 DAY), 'Student Centre Lawn'),
(5, '24-Hour Campus Hackathon', 'Form a team and build a solution for a campus problem in 24 hours. Prizes for the top three teams.', DATE_ADD(NOW(), INTERVAL 15 DAY), 'ICT Lab 3'),
(6, 'Windhoek Sunset Photo Walk', 'Bring your camera or phone. We will shoot golden hour around the city.', DATE_ADD(NOW(), INTERVAL 7 DAY), 'Meet at Student Centre'),
(8, 'Pitch Night', 'Five student founders pitch to a panel of local entrepreneurs.', DATE_ADD(NOW(), INTERVAL 25 DAY), 'Business Incubator'),
(1, 'Simultaneous Exhibition (past)', 'A visiting master played 20 students at once.', DATE_SUB(NOW(), INTERVAL 14 DAY), 'Library Seminar Room');

INSERT INTO event_rsvps (event_id, user_id) VALUES (1, 2), (5, 2);

INSERT INTO messages (name, email, subject, message, is_read) VALUES
('Maria Shikongo', 'maria@example.com', 'Starting a new club', 'Hi, how can I register a new club for the Environmental Society?', 0);
