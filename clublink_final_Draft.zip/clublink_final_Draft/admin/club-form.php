<?php
$base = '../';
require __DIR__ . '/../includes/init.php';
require_admin();

$img_dir = __DIR__ . '/../assets/images';
$id = (int)($_GET['id'] ?? 0);
$club = $id ? row($conn, "SELECT * FROM clubs WHERE club_id = ?", 'i', [$id]) : null;
if ($id && !$club) { flash('danger', 'Club not found.'); redirect('clubs.php'); }

$f = $club ?: ['club_name' => '', 'category' => 'Social', 'description' => '', 'meeting_time' => '', 'location' => '', 'image' => 'default.jpg'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $f['club_name']    = trim($_POST['club_name'] ?? '');
    $f['category']     = $_POST['category'] ?? '';
    $f['description']  = trim($_POST['description'] ?? '');
    $f['meeting_time'] = trim($_POST['meeting_time'] ?? '') ?: 'To be announced';
    $f['location']     = trim($_POST['location'] ?? '') ?: 'NUST Main Campus';

    if (mb_strlen($f['club_name']) < 3 || mb_strlen($f['club_name']) > 120) { $errors[] = 'Club name must be 3–120 characters.'; }
    if (!in_array($f['category'], CATEGORIES, true)) { $errors[] = 'Choose a valid category.'; }
    if (mb_strlen($f['description']) < 20) { $errors[] = 'Description must be at least 20 characters.'; }
    if (mb_strlen($f['meeting_time']) > 100 || mb_strlen($f['location']) > 120) { $errors[] = 'Meeting time or location is too long.'; }

    // Name must be unique (ignore the club being edited)
    if (!$errors && val($conn, "SELECT COUNT(*) FROM clubs WHERE club_name = ? AND club_id <> ?", 'si', [$f['club_name'], $id]) > 0) {
        $errors[] = 'Another club already uses that name.';
    }

    $new_image = null;
    if (!$errors) {
        $new_image = upload_image($_FILES['image'] ?? [], $upload_error, $img_dir);
        if ($upload_error) { $errors[] = $upload_error; }
    }

    if (!$errors) {
        if ($club) {
            $image = $new_image ?: $club['image'];
            q($conn, "UPDATE clubs SET club_name=?, category=?, description=?, meeting_time=?, location=?, image=? WHERE club_id=?",
              'ssssssi', [$f['club_name'], $f['category'], $f['description'], $f['meeting_time'], $f['location'], $image, $id]);
            if ($new_image) { delete_uploaded_image($club['image'], $img_dir); }
            flash('success', 'Club updated.');
        } else {
            $image = $new_image ?: 'default.jpg';
            q($conn, "INSERT INTO clubs (club_name, category, description, meeting_time, location, image) VALUES (?,?,?,?,?,?)",
              'ssssss', [$f['club_name'], $f['category'], $f['description'], $f['meeting_time'], $f['location'], $image]);
            flash('success', 'Club added.');
        }
        redirect('clubs.php');
    }
}

$page_title = $club ? 'Edit Club' : 'Add Club';
$admin_current = 'clubs.php';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1><?= $club ? 'Edit club' : 'Add new club' ?></h1>
<?php foreach ($errors as $err): ?>
    <div class="alert alert-danger" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <span><?= e($err) ?></span></div>
<?php endforeach; ?>
<form method="post" enctype="multipart/form-data" class="panel form-wide">
    <?= csrf_field() ?>
    <div class="field"><label for="club_name">Club name</label><input id="club_name" name="club_name" value="<?= e($f['club_name']) ?>" required minlength="3" maxlength="120"></div>
    <div class="field">
        <label for="category">Category</label>
        <select id="category" name="category" required>
            <?php foreach (CATEGORIES as $c): ?><option <?= $f['category'] === $c ? 'selected' : '' ?>><?= e($c) ?></option><?php endforeach; ?>
        </select>
    </div>
    <div class="field"><label for="description">Description</label><textarea id="description" name="description" rows="5" required minlength="20"><?= e($f['description']) ?></textarea></div>
    <div class="field"><label for="meeting_time">Meeting time</label><input id="meeting_time" name="meeting_time" value="<?= e($f['meeting_time']) ?>" placeholder="e.g. Fridays 15:00" maxlength="100"></div>
    <div class="field"><label for="location">Location</label><input id="location" name="location" value="<?= e($f['location']) ?>" placeholder="e.g. Student Centre" maxlength="120"></div>
    <div class="field">
        <label for="image">Club image <small>(JPG, PNG, WEBP or GIF, max 2 MB)</small></label>
        <?php if ($club): ?><img class="thumb big" src="<?= e(club_image($club['image'], '../')) ?>" alt="Current image" id="imgPreview"><?php else: ?><img class="thumb big" id="imgPreview" alt="" hidden><?php endif; ?>
        <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp,image/gif">
    </div>
    <div class="btn-row">
        <button class="btn"><i class="fa-solid fa-floppy-disk"></i> <?= $club ? 'Save changes' : 'Add club' ?></button>
        <a href="clubs.php" class="btn btn-outline">Cancel</a>
    </div>
</form>
<?php include __DIR__ . '/_end.php'; include __DIR__ . '/../includes/footer.php'; ?>
