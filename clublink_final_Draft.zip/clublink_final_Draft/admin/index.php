<?php
$base = '../';
require __DIR__ . '/../includes/init.php';
require_admin();

$counts = [
    'clubs'    => (int)val($conn, "SELECT COUNT(*) FROM clubs"),
    'users'    => (int)val($conn, "SELECT COUNT(*) FROM users"),
    'members'  => (int)val($conn, "SELECT COUNT(*) FROM memberships"),
    'events'   => (int)val($conn, "SELECT COUNT(*) FROM events WHERE event_date >= NOW()"),
];
$per_club = rows($conn,
    "SELECT c.club_name, COUNT(m.membership_id) AS total
     FROM clubs c LEFT JOIN memberships m ON m.club_id = c.club_id
     GROUP BY c.club_id ORDER BY total DESC, c.club_name LIMIT 8");
$max = max(1, ...array_column($per_club, 'total') ?: [1]);
$recent_users = rows($conn, "SELECT full_name, email, created_at FROM users ORDER BY created_at DESC, user_id DESC LIMIT 5");
$recent_msgs  = rows($conn, "SELECT message_id, name, subject, is_read, created_at FROM messages ORDER BY created_at DESC, message_id DESC LIMIT 5");

$page_title = 'Admin Overview';
$admin_current = 'index.php';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1>Dashboard overview</h1>
<ul class="stats stats-inline">
    <li><strong><?= $counts['clubs'] ?></strong><span>Clubs</span></li>
    <li><strong><?= $counts['users'] ?></strong><span>Users</span></li>
    <li><strong><?= $counts['members'] ?></strong><span>Memberships</span></li>
    <li><strong><?= $counts['events'] ?></strong><span>Upcoming events</span></li>
</ul>

<div class="grid grid-2">
    <div class="panel">
        <h2>Members per club</h2>
        <ul class="bars">
            <?php foreach ($per_club as $b): ?>
                <li>
                    <span class="bar-label"><?= e($b['club_name']) ?></span>
                    <span class="bar-track"><span class="bar-fill" style="width: <?= round(($b['total'] / $max) * 100) ?>%"></span></span>
                    <span class="bar-val"><?= (int)$b['total'] ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <div class="panel">
        <h2>Latest messages</h2>
        <ul class="plain-list">
            <?php foreach ($recent_msgs as $m): ?>
                <li><a href="messages.php"><?= $m['is_read'] ? '' : '<span class="dot" title="Unread"></span>' ?> <strong><?= e($m['subject']) ?></strong></a><br><small><?= e($m['name']) ?> &middot; <?= e(fmt_date($m['created_at'], 'j M, H:i')) ?></small></li>
            <?php endforeach; ?>
            <?php if (!$recent_msgs): ?><li>No messages yet.</li><?php endif; ?>
        </ul>
        <h2>New users</h2>
        <ul class="plain-list">
            <?php foreach ($recent_users as $u): ?>
                <li><strong><?= e($u['full_name']) ?></strong><br><small><?= e($u['email']) ?></small></li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>
<div class="btn-row">
    <a href="club-form.php" class="btn"><i class="fa-solid fa-plus"></i> Add club</a>
    <a href="event-form.php" class="btn btn-dark"><i class="fa-solid fa-plus"></i> Add event</a>
</div>
<?php include __DIR__ . '/_end.php'; include __DIR__ . '/../includes/footer.php'; ?>
