<?php
// Admin sidebar partial. Expects $admin_current (file name) to be set.
$unread = (int)val($conn, "SELECT COUNT(*) FROM messages WHERE is_read = 0");
$items = [
    'index.php'    => ['Overview', 'fa-gauge'],
    'clubs.php'    => ['Clubs', 'fa-people-group'],
    'events.php'   => ['Events', 'fa-calendar-days'],
    'users.php'    => ['Users', 'fa-users'],
    'messages.php' => ['Messages', 'fa-inbox'],
];
?>
<div class="admin-layout">
    <aside class="admin-side" aria-label="Admin menu">
        <h2><i class="fa-solid fa-shield-halved"></i> Admin</h2>
        <ul>
            <?php foreach ($items as $file => [$label, $icon]): ?>
                <li>
                    <a href="<?= $file ?>" class="<?= ($admin_current ?? '') === $file ? 'active' : '' ?>">
                        <i class="fa-solid <?= $icon ?>"></i> <?= $label ?>
                        <?php if ($file === 'messages.php' && $unread): ?><span class="pill"><?= $unread ?></span><?php endif; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </aside>
    <section class="admin-content">
