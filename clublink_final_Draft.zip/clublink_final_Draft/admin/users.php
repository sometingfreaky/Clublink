<?php
$base = '../';
require __DIR__ . '/../includes/init.php';
require_admin();
$me = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $uid = (int)($_POST['user_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($uid === $me) {
        flash('danger', 'You cannot change or delete your own account here.');
    } elseif ($action === 'role') {
        $role = ($_POST['role'] ?? '') === 'admin' ? 'admin' : 'student';
        q($conn, "UPDATE users SET role = ? WHERE user_id = ?", 'si', [$role, $uid]);
        flash('success', 'Role updated.');
    } elseif ($action === 'delete') {
        q($conn, "DELETE FROM users WHERE user_id = ?", 'i', [$uid]);
        flash('success', 'User deleted.');
    }
    redirect('users.php');
}

$search = trim($_GET['search'] ?? '');
$like = '%' . $search . '%';
$users = rows($conn,
    "SELECT u.*, (SELECT COUNT(*) FROM memberships m WHERE m.user_id = u.user_id) AS clubs
     FROM users u WHERE u.full_name LIKE ? OR u.email LIKE ? ORDER BY u.created_at DESC, u.user_id DESC", 'ss', [$like, $like]);

$page_title = 'Manage Users';
$admin_current = 'users.php';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1>Manage users</h1>
<form method="get" class="filter-bar compact">
    <div class="field"><label for="s" class="sr-only">Search</label><input id="s" type="search" name="search" value="<?= e($search) ?>" placeholder="Search name or email…"></div>
    <button class="btn btn-small">Search</button>
</form>
<div class="table-wrap">
    <table class="table">
        <thead><tr><th scope="col">Name</th><th scope="col">Email</th><th scope="col">Role</th><th scope="col">Clubs</th><th scope="col">Joined</th><th scope="col">Actions</th></tr></thead>
        <tbody>
        <?php foreach ($users as $u): $self = (int)$u['user_id'] === $me; ?>
            <tr>
                <td data-label="Name"><strong><?= e($u['full_name']) ?></strong> <?= $self ? '<small>(you)</small>' : '' ?></td>
                <td data-label="Email"><?= e($u['email']) ?></td>
                <td data-label="Role"><span class="badge <?= $u['role'] === 'admin' ? 'badge-admin' : 'badge-social' ?>"><?= e($u['role']) ?></span></td>
                <td data-label="Clubs"><?= (int)$u['clubs'] ?></td>
                <td data-label="Joined"><?= e(fmt_date($u['created_at'], 'j M Y')) ?></td>
                <td data-label="Actions" class="actions">
                    <?php if (!$self): ?>
                        <form method="post" class="inline">
                            <?= csrf_field() ?><input type="hidden" name="action" value="role"><input type="hidden" name="user_id" value="<?= (int)$u['user_id'] ?>">
                            <input type="hidden" name="role" value="<?= $u['role'] === 'admin' ? 'student' : 'admin' ?>">
                            <button class="link-action confirm" data-confirm="Change role of <?= e($u['full_name']) ?>?"><i class="fa-solid fa-user-gear"></i> Make <?= $u['role'] === 'admin' ? 'student' : 'admin' ?></button>
                        </form>
                        <form method="post" class="inline">
                            <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="user_id" value="<?= (int)$u['user_id'] ?>">
                            <button class="link-danger confirm" data-confirm="Delete <?= e($u['full_name']) ?> permanently?"><i class="fa-solid fa-trash"></i> Delete</button>
                        </form>
                    <?php else: ?>&mdash;<?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$users): ?><tr><td colspan="6" class="center empty-cell">No users found.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php include __DIR__ . '/_end.php'; include __DIR__ . '/../includes/footer.php'; ?>
