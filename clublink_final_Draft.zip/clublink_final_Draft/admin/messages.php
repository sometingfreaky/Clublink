<?php
$base = '../';
require __DIR__ . '/../includes/init.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $mid = (int)($_POST['message_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($action === 'toggle') {
        q($conn, "UPDATE messages SET is_read = 1 - is_read WHERE message_id = ?", 'i', [$mid]);
        flash('success', 'Message updated.');
    } elseif ($action === 'delete') {
        q($conn, "DELETE FROM messages WHERE message_id = ?", 'i', [$mid]);
        flash('success', 'Message deleted.');
    }
    redirect('messages.php');
}

$msgs = rows($conn, "SELECT * FROM messages ORDER BY is_read ASC, created_at DESC, message_id DESC");

$page_title = 'Messages';
$admin_current = 'messages.php';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1>Contact messages</h1>
<div class="stack">
    <?php foreach ($msgs as $m): ?>
        <details class="card msg <?= $m['is_read'] ? '' : 'unread' ?>">
            <summary>
                <?= $m['is_read'] ? '' : '<span class="dot" title="Unread"></span>' ?>
                <strong><?= e($m['subject']) ?></strong>
                <span class="meta">from <?= e($m['name']) ?> &middot; <?= e(fmt_date($m['created_at'], 'j M Y, H:i')) ?></span>
            </summary>
            <p class="meta"><i class="fa-solid fa-envelope"></i> <a href="mailto:<?= e($m['email']) ?>"><?= e($m['email']) ?></a></p>
            <p><?= nl2br(e($m['message'])) ?></p>
            <form method="post" class="btn-row">
                <?= csrf_field() ?><input type="hidden" name="message_id" value="<?= (int)$m['message_id'] ?>">
                <button name="action" value="toggle" class="btn btn-small btn-outline"><?= $m['is_read'] ? 'Mark unread' : 'Mark as read' ?></button>
                <button name="action" value="delete" class="btn btn-small btn-danger confirm" data-confirm="Delete this message?"><i class="fa-solid fa-trash"></i> Delete</button>
            </form>
        </details>
    <?php endforeach; ?>
    <?php if (!$msgs): ?><div class="empty"><i class="fa-regular fa-inbox"></i><p>No messages yet.</p></div><?php endif; ?>
</div>
<?php include __DIR__ . '/_end.php'; include __DIR__ . '/../includes/footer.php'; ?>
