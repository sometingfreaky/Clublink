<?php
$base = '../';
require __DIR__ . '/../includes/init.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_check();
    q($conn, "DELETE FROM events WHERE event_id = ?", 'i', [(int)($_POST['event_id'] ?? 0)]);
    flash('success', 'Event deleted.');
    redirect('events.php');
}

$events = rows($conn,
    "SELECT e.*, c.club_name, (SELECT COUNT(*) FROM event_rsvps r WHERE r.event_id = e.event_id) AS going
     FROM events e JOIN clubs c ON c.club_id = e.club_id ORDER BY e.event_date DESC");

$page_title = 'Manage Events';
$admin_current = 'events.php';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<div class="section-head">
    <h1>Manage events</h1>
    <a href="event-form.php" class="btn"><i class="fa-solid fa-plus"></i> Add event</a>
</div>
<div class="table-wrap">
    <table class="table">
        <thead><tr><th scope="col">Event</th><th scope="col">Club</th><th scope="col">Date</th><th scope="col">RSVPs</th><th scope="col">Actions</th></tr></thead>
        <tbody>
        <?php foreach ($events as $ev): $past = strtotime($ev['event_date']) < time(); ?>
            <tr>
                <td data-label="Event"><strong><?= e($ev['title']) ?></strong><br><small><?= e($ev['location']) ?></small></td>
                <td data-label="Club"><?= e($ev['club_name']) ?></td>
                <td data-label="Date"><?= e(fmt_date($ev['event_date'], 'j M Y, H:i')) ?> <?= $past ? '<span class="badge badge-past">Past</span>' : '' ?></td>
                <td data-label="RSVPs"><?= (int)$ev['going'] ?></td>
                <td data-label="Actions" class="actions">
                    <a href="event-form.php?id=<?= (int)$ev['event_id'] ?>" class="link-action"><i class="fa-solid fa-pen"></i> Edit</a>
                    <form method="post" class="inline">
                        <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="event_id" value="<?= (int)$ev['event_id'] ?>">
                        <button class="link-danger confirm" data-confirm="Delete this event?"><i class="fa-solid fa-trash"></i> Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$events): ?><tr><td colspan="5" class="center empty-cell">No events yet.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php include __DIR__ . '/_end.php'; include __DIR__ . '/../includes/footer.php'; ?>
