<?php
$base = '../';
require __DIR__ . '/../includes/init.php';
require_admin();

$id = (int)($_GET['id'] ?? 0);
$event = $id ? row($conn, "SELECT * FROM events WHERE event_id = ?", 'i', [$id]) : null;
if ($id && !$event) { flash('danger', 'Event not found.'); redirect('events.php'); }

$f = $event ?: ['club_id' => (int)($_GET['club'] ?? 0), 'title' => '', 'description' => '',
                'event_date' => date('Y-m-d H:i:s', strtotime('+7 days 15:00')), 'location' => ''];
$clubs = rows($conn, "SELECT club_id, club_name FROM clubs ORDER BY club_name");
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $f['club_id']     = (int)($_POST['club_id'] ?? 0);
    $f['title']       = trim($_POST['title'] ?? '');
    $f['description'] = trim($_POST['description'] ?? '');
    $f['location']    = trim($_POST['location'] ?? '');
    $dt = DateTime::createFromFormat('Y-m-d\TH:i', $_POST['event_date'] ?? '');
    $f['event_date']  = $dt ? $dt->format('Y-m-d H:i:s') : '';

    if (!val($conn, "SELECT COUNT(*) FROM clubs WHERE club_id = ?", 'i', [$f['club_id']])) { $errors[] = 'Choose a club.'; }
    if (mb_strlen($f['title']) < 3 || mb_strlen($f['title']) > 150) { $errors[] = 'Title must be 3–150 characters.'; }
    if (mb_strlen($f['description']) < 10) { $errors[] = 'Description must be at least 10 characters.'; }
    if ($f['location'] === '' || mb_strlen($f['location']) > 120) { $errors[] = 'Enter a location (max 120 characters).'; }
    if (!$dt) { $errors[] = 'Enter a valid date and time.'; }

    if (!$errors) {
        if ($event) {
            q($conn, "UPDATE events SET club_id=?, title=?, description=?, event_date=?, location=? WHERE event_id=?",
              'issssi', [$f['club_id'], $f['title'], $f['description'], $f['event_date'], $f['location'], $id]);
            flash('success', 'Event updated.');
        } else {
            q($conn, "INSERT INTO events (club_id, title, description, event_date, location) VALUES (?,?,?,?,?)",
              'issss', [$f['club_id'], $f['title'], $f['description'], $f['event_date'], $f['location']]);
            flash('success', 'Event added.');
        }
        redirect('events.php');
    }
}

$page_title = $event ? 'Edit Event' : 'Add Event';
$admin_current = 'events.php';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<h1><?= $event ? 'Edit event' : 'Add new event' ?></h1>
<?php foreach ($errors as $err): ?>
    <div class="alert alert-danger" role="alert"><i class="fa-solid fa-circle-exclamation"></i> <span><?= e($err) ?></span></div>
<?php endforeach; ?>
<form method="post" class="panel form-wide">
    <?= csrf_field() ?>
    <div class="field">
        <label for="club_id">Club</label>
        <select id="club_id" name="club_id" required>
            <option value="">Select a club…</option>
            <?php foreach ($clubs as $c): ?><option value="<?= (int)$c['club_id'] ?>" <?= (int)$f['club_id'] === (int)$c['club_id'] ? 'selected' : '' ?>><?= e($c['club_name']) ?></option><?php endforeach; ?>
        </select>
    </div>
    <div class="field"><label for="title">Title</label><input id="title" name="title" value="<?= e($f['title']) ?>" required minlength="3" maxlength="150"></div>
    <div class="field"><label for="description">Description</label><textarea id="description" name="description" rows="4" required minlength="10"><?= e($f['description']) ?></textarea></div>
    <div class="field"><label for="event_date">Date &amp; time</label><input type="datetime-local" id="event_date" name="event_date" value="<?= e(date('Y-m-d\TH:i', strtotime($f['event_date']))) ?>" required></div>
    <div class="field"><label for="location">Location</label><input id="location" name="location" value="<?= e($f['location']) ?>" required maxlength="120"></div>
    <div class="btn-row">
        <button class="btn"><i class="fa-solid fa-floppy-disk"></i> <?= $event ? 'Save changes' : 'Add event' ?></button>
        <a href="events.php" class="btn btn-outline">Cancel</a>
    </div>
</form>
<?php include __DIR__ . '/_end.php'; include __DIR__ . '/../includes/footer.php'; ?>
