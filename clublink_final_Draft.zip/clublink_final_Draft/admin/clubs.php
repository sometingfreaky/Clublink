<?php
$base = '../';
require __DIR__ . '/../includes/init.php';
require_admin();

$img_dir = __DIR__ . '/../assets/images';

// ---- DELETE (POST + CSRF) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrf_check();
    $id = (int)($_POST['club_id'] ?? 0);
    $club = row($conn, "SELECT club_name, image FROM clubs WHERE club_id = ?", 'i', [$id]);
    if ($club) {
        q($conn, "DELETE FROM clubs WHERE club_id = ?", 'i', [$id]);   // memberships & events cascade
        delete_uploaded_image($club['image'], $img_dir);
        flash('success', 'Club “' . $club['club_name'] . '” deleted.');
    }
    redirect('clubs.php');
}

$search = trim($_GET['search'] ?? '');
$like = '%' . $search . '%';
$clubs = rows($conn,
    "SELECT c.*, (SELECT COUNT(*) FROM memberships m WHERE m.club_id = c.club_id) AS members,
                 (SELECT COUNT(*) FROM events e WHERE e.club_id = c.club_id) AS events
     FROM clubs c WHERE c.club_name LIKE ? ORDER BY c.club_id DESC", 's', [$like]);

$page_title = 'Manage Clubs';
$admin_current = 'clubs.php';
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/_nav.php';
?>
<div class="section-head">
    <h1>Manage clubs</h1>
    <a href="club-form.php" class="btn"><i class="fa-solid fa-plus"></i> Add club</a>
</div>
<form method="get" class="filter-bar compact">
    <div class="field"><label for="s" class="sr-only">Search</label><input id="s" type="search" name="search" value="<?= e($search) ?>" placeholder="Search clubs…"></div>
    <button class="btn btn-small">Search</button>
</form>
<div class="table-wrap">
    <table class="table">
        <thead><tr><th scope="col">Image</th><th scope="col">Club</th><th scope="col">Category</th><th scope="col">Members</th><th scope="col">Events</th><th scope="col">Actions</th></tr></thead>
        <tbody>
        <?php foreach ($clubs as $c): ?>
            <tr>
                <td data-label="Image"><img class="thumb" src="<?= e(club_image($c['image'], '../')) ?>" alt=""></td>
                <td data-label="Club"><strong><?= e($c['club_name']) ?></strong><br><small><?= e($c['meeting_time']) ?></small></td>
                <td data-label="Category"><span class="badge badge-<?= strtolower(e($c['category'])) ?>"><?= e($c['category']) ?></span></td>
                <td data-label="Members"><?= (int)$c['members'] ?></td>
                <td data-label="Events"><?= (int)$c['events'] ?></td>
                <td data-label="Actions" class="actions">
                    <a href="../club-details.php?id=<?= (int)$c['club_id'] ?>" class="link-action"><i class="fa-solid fa-eye"></i> View</a>
                    <a href="club-form.php?id=<?= (int)$c['club_id'] ?>" class="link-action"><i class="fa-solid fa-pen"></i> Edit</a>
                    <form method="post" class="inline">
                        <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="club_id" value="<?= (int)$c['club_id'] ?>">
                        <button class="link-danger confirm" data-confirm="Delete “<?= e($c['club_name']) ?>”? Its memberships and events will also be deleted."><i class="fa-solid fa-trash"></i> Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$clubs): ?><tr><td colspan="6" class="center empty-cell">No clubs found.</td></tr><?php endif; ?>
        </tbody>
    </table>
</div>
<?php include __DIR__ . '/_end.php'; include __DIR__ . '/../includes/footer.php'; ?>
