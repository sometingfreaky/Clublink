/* =====================================================================
   Club Link - client-side JavaScript
   Features: mobile menu, dark mode, form validation, password strength,
   show/hide password, live character counter, confirm dialogs,
   dismissible alerts, animated counters, image preview, back-to-top.
   ===================================================================== */
"use strict";

// ---------- Small helpers ----------
const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => Array.from(scope.querySelectorAll(selector));

function showFieldError(input, message) {
    input.classList.add("invalid");
    input.setAttribute("aria-invalid", "true");
    input.title = message;
}
function clearFieldError(input) {
    input.classList.remove("invalid");
    input.removeAttribute("aria-invalid");
    input.title = "";
}
function showFormError(box, messages) {
    if (!box) return;
    box.innerHTML = "<i class='fa-solid fa-circle-exclamation'></i> <span>" + messages.join("<br>") + "</span>";
    box.hidden = false;
    box.scrollIntoView({ behavior: "smooth", block: "center" });
}

// ---------- Validation rules (functions returning an error string or "") ----------
const validators = {
    email: (value) => (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) ? "" : "Enter a valid email address."),
    name: (value) => (value.trim().length >= 2 ? "" : "Name must be at least 2 characters."),
    password: (value) => {
        if (value.length < 8) return "Password must be at least 8 characters.";
        if (!/[A-Za-z]/.test(value) || !/\d/.test(value)) return "Password needs a letter and a number.";
        return "";
    },
};

// Scores a password from 0 to 4
function passwordScore(value) {
    const checks = [
        value.length >= 8,
        /[a-z]/.test(value) && /[A-Z]/.test(value),
        /\d/.test(value),
        /[^A-Za-z0-9]/.test(value),
    ];
    return checks.filter(Boolean).length;
}

document.addEventListener("DOMContentLoaded", () => {
    // ---------- Mobile navigation ----------
    const navToggle = $("#navToggle");
    const navMenu = $("#navMenu");
    if (navToggle && navMenu) {
        navToggle.addEventListener("click", () => {
            const open = navMenu.classList.toggle("open");
            navToggle.setAttribute("aria-expanded", String(open));
            navToggle.firstElementChild.className = open ? "fa-solid fa-xmark" : "fa-solid fa-bars";
        });
    }

    // ---------- Dark / light theme (remembered in localStorage) ----------
    const themeToggle = $("#themeToggle");
    const root = document.documentElement;
    const syncThemeIcon = () => {
        if (themeToggle) {
            themeToggle.innerHTML = root.getAttribute("data-theme") === "dark"
                ? "<i class='fa-solid fa-sun'></i>" : "<i class='fa-solid fa-moon'></i>";
        }
    };
    syncThemeIcon();
    if (themeToggle) {
        themeToggle.addEventListener("click", () => {
            const dark = root.getAttribute("data-theme") !== "dark";
            if (dark) root.setAttribute("data-theme", "dark"); else root.removeAttribute("data-theme");
            try { localStorage.setItem("theme", dark ? "dark" : "light"); } catch (e) { /* storage blocked */ }
            syncThemeIcon();
        });
    }

    // ---------- Dismissible alerts (+ auto-hide success messages) ----------
    $$(".alert-close").forEach((btn) => btn.addEventListener("click", () => btn.parentElement.remove()));
    $$(".alert-success").forEach((box) => setTimeout(() => box.remove(), 6000));

    // ---------- Confirm dialogs for destructive actions ----------
    $$(".confirm").forEach((btn) => {
        btn.addEventListener("click", (event) => {
            const message = btn.dataset.confirm || "Are you sure?";
            if (!window.confirm(message)) event.preventDefault();
        });
    });

    // ---------- Registration form validation ----------
    const registerForm = $("#registerForm");
    if (registerForm) {
        const nameInput = $("#name", registerForm);
        const emailInput = $("#email", registerForm);
        const pwInput = $("#password", registerForm);
        const confirmInput = $("#confirm_password", registerForm);
        const errorBox = $("#js-error");
        const bar = $("#strengthBar");
        const text = $("#strengthText");

        const levels = [
            { label: "Too weak", color: "#dc2626", width: "15%" },
            { label: "Weak", color: "#ea580c", width: "35%" },
            { label: "Fair", color: "#ca8a04", width: "60%" },
            { label: "Good", color: "#65a30d", width: "80%" },
            { label: "Strong", color: "#16a34a", width: "100%" },
        ];

        pwInput.addEventListener("input", () => {
            const level = levels[passwordScore(pwInput.value)];
            bar.style.width = pwInput.value ? level.width : "0";
            bar.style.background = level.color;
            text.textContent = pwInput.value ? "Strength: " + level.label : "At least 8 characters, with a letter and a number.";
        });

        // Validate a field as soon as the user leaves it
        [[nameInput, validators.name], [emailInput, validators.email], [pwInput, validators.password]].forEach(([input, rule]) => {
            input.addEventListener("blur", () => {
                const msg = rule(input.value);
                msg ? showFieldError(input, msg) : clearFieldError(input);
            });
        });

        registerForm.addEventListener("submit", (event) => {
            const problems = [];
            [[nameInput, validators.name], [emailInput, validators.email], [pwInput, validators.password]].forEach(([input, rule]) => {
                const msg = rule(input.value);
                if (msg) { problems.push(msg); showFieldError(input, msg); } else { clearFieldError(input); }
            });
            if (pwInput.value !== confirmInput.value) {
                problems.push("Passwords do not match.");
                showFieldError(confirmInput, "Passwords do not match.");
            } else {
                clearFieldError(confirmInput);
            }
            if (problems.length) {
                event.preventDefault();
                showFormError(errorBox, problems);
            }
        });
    }

    // ---------- Contact form: validation + live character counter ----------
    const contactForm = $("#contactForm");
    if (contactForm) {
        const msgBox = $("#message", contactForm);
        const counter = $("#charCount");
        const updateCount = () => { counter.textContent = msgBox.value.length; };
        msgBox.addEventListener("input", updateCount);
        updateCount();

        contactForm.addEventListener("submit", (event) => {
            const emailInput = $("#email", contactForm);
            const problems = [];
            if (validators.email(emailInput.value)) problems.push(validators.email(emailInput.value));
            if (msgBox.value.trim().length < 10) problems.push("Message must be at least 10 characters.");
            if (problems.length) {
                event.preventDefault();
                alert(problems.join("\n"));
            }
        });
    }

    // ---------- Show / hide password buttons ----------
    $$(".pw-toggle").forEach((btn) => {
        btn.addEventListener("click", () => {
            const input = document.getElementById(btn.dataset.target);
            const show = input.type === "password";
            input.type = show ? "text" : "password";
            btn.innerHTML = show ? "<i class='fa-regular fa-eye-slash'></i>" : "<i class='fa-regular fa-eye'></i>";
            btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
        });
    });

    // ---------- Auto-submit filters when a dropdown changes ----------
    const filterForm = $("#filterForm");
    if (filterForm) {
        $$("select", filterForm).forEach((sel) => sel.addEventListener("change", () => filterForm.submit()));
    }

    // ---------- Animated counters on the home page ----------
    $$("[data-count]").forEach((el) => {
        const target = parseInt(el.dataset.count, 10);
        if (!Number.isFinite(target) || target === 0 || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
        let current = 0;
        const step = Math.max(1, Math.ceil(target / 30));
        const timer = setInterval(() => {
            current = Math.min(target, current + step);
            el.textContent = current;
            if (current >= target) clearInterval(timer);
        }, 30);
    });

    // ---------- Image preview in the admin club form ----------
    const imageInput = $("#image");
    const preview = $("#imgPreview");
    if (imageInput && preview) {
        imageInput.addEventListener("change", () => {
            const file = imageInput.files[0];
            if (!file) return;
            if (file.size > 2 * 1024 * 1024) {
                alert("Image must be 2 MB or smaller.");
                imageInput.value = "";
                return;
            }
            preview.src = URL.createObjectURL(file);
            preview.hidden = false;
        });
    }

    // ---------- Back-to-top button ----------
    const toTop = $("#backToTop");
    if (toTop) {
        window.addEventListener("scroll", () => toTop.classList.toggle("show", window.scrollY > 400), { passive: true });
        toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
    }
});
